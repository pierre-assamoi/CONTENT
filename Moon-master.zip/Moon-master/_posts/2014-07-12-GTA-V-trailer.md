---
layout: post
title:  "GTA V Trailer"
image: ''
date:   2014-07-12 17:08:31
tags:
- LIFE ライフスタイル
---


_Initialement publié sur DopeKultur_  

![GTA V TRAILER](https://i.ibb.co/fnMCgPq/grand-theft-auto-v-screenshot-02-ps4-us-27oct14.jpg)

**GTA V se dévoile un peu plus dans une nouvelle vidéo et ce qu’on peut dire c’est que les petits gars de Rockstar n’ont pas fait les choses à moitié.**

Le clip nous montre Michael, Trevor et Franklin, les trois protagonistes de ce nouvel opus, dans un Los Santos riche en détail, possédant une impressionnante panoplie de paysages et c’est dans cette métropole largement inspirer de Los Angeles que nos trois cailleras commettront leurs méfaits.

La vidéo nous donne également un aperçu du gameplay, on y voit quelques missions, cependant on retiendra surtout celle où les trois personnages sont impliqués, chacun à un poste différent, avec la possibilité de passer alternativement de l’un à l’autre en toute fluidité.
**Hideo Kojima**, à qui l’on doit la série _Metal Gear Solid_, reconnait lui aussi avoir été impressionné par le clip, il a récemment confié sur Twitter qu’il trouvait la vidéo géniale et qu’une telle gestion libre des personnages représente d’après lui le futur du jeu vidéo, néanmoins il a aussi avoué que tout cela le rendait triste, car il ne pense pas que le prochain MGS sera au niveau, le japonais néanmoins fairplay a salué la performance des équipes de Rockstar.

Bref vivement le 17 septembre prochain, date officielle de sortie de GTA V en Europe et aux États-Unis. Et pour ceux qui ne l’auraient pas encore vu, le trailer est juste en dessous.

<div align="center">
<iframe width="560" height="315" src="https://www.youtube.com/embed/N-xHcvug3WI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
