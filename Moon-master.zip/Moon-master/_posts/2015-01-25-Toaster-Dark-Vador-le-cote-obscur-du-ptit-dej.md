---
layout: post
title:  "Toaster Dark Vador, le côté obscur du ptit dej"
image: ''
date:   2015-01-25 16:41:31
tags:
- LIFE ライフスタイル
description: ''
categories:
- ''
---


_Publié sur DopeKultur_  

_Initialement publié sur DopeKultur_  

![toast darth vader](https://i.ibb.co/34tnktt/darth-vader-toaster-12056.jpg)  

**Il y a des matins, où on se lève du mauvais pied, où rien ne va, où la simple idée de penser à la journée qui se prépare nous fous dans une colère noire.** 

## Une légère perturbation dans la force

Dans ces moments, deux choix s’imposent à nous. Soit tenter de faire fi de cet accès de rage qui finira irrémédiablement par nous ronger de l’intérieur. Pour arriver à retrouver la paix intérieure chacun sa méthode; prendre de longues respirations, écouter des chants tribaux Maya aux vertus apaisantes, tenter de rentrer en communion avec la nature en reproduisant la danse cosmique de la déesse Shiva, ou que sais-je encore… 

La deuxième solution consiste à laisser toute cette force dévastatrice se propager, jusqu’au basculement définitif vers le Côté Obscur, à l’image d’Anakin Skywalker. Les aspirants Sith peuvent désormais afficher fièrement leur allégeance à l’Empire Galactique, en dégustant des tartines fraichement toastées à l’effigie du Seigneur Dark Vador.
