---
layout: post
title:  "ACTION BRONSON DANS TES OREILLES"
image: ''
date:   2015-01-25 14:06:31
tags:
- LIFE ライフスタイル
description: ''
categories:
- ''
---


_Publié sur DopeKultur_  

![action bronson cover](https://i.ibb.co/MhzsY07/action-bronson-new-album.jpg)  

En 2008, Arian Asllani rend son tablier de chef cuistot pour se lancer dans le rap et devenir **Action Bronson**. Le rappeur originaire du Queens prépare depuis un moment **son troisième album studio, Mr Wonderfull*. Bronsonliño avait déjà commencé à faire monter la sauce, l’été dernier, avec [**Easy Rider**](https://youtu.be/58RSC7HO9aU), morceau en hommage au mythique road movie des années 70. Après des mois de silence, voilà que sort **Actin Crazy**, produit par Noah “40″ Shebib.  

## "...I'M OUT HERE ACTIN' CRAZY"

Cette fois, Action Bronson, nous livre un single beaucoup plus personnel. Loin du trip biker/hippy d’Easy Rider. Actin Crazy est un morceau plus introspectif, le rappeur s’y interroge à propos des répercussions causées par sa récente célébrité sur sa santé mentale.

![action bronson gif](https://i.ibb.co/P6qKsQ5/action-bronson-the-wheel-1.gif)

La tracklist de Mr. Wonderfull a été récemment dévoilée. La galette comptera 13 titres, plusieurs invités dont **Chance The Rapper, Big Body Bes, Meyhem Lauren et Chauncy Sherod**. L’opening de l’album « Brand New Car » contiendra même une apparition de Billy Joel. La légende new yorkaise a autorisé Action Bronson à _sampler_ une de ses chansons.

1. Brand New Car
2. When I Rise
3. Terry
4. Actin crazy
5. Falconry
6. THUG LOVE STORY 2017 THE MUSICAL
7. A. City Boy Blues
8. B. A Light In The Addict
9. C. Baby Blue
10. Only In America
11. Galactic Love
12. The Road
13. Easy Rider

<div align="center">
<iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/184964202&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
</div>