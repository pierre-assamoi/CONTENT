---
layout: post
title:  "A$AP ROCKY AU SUNDANCE 2015"
image: ''
date:   2015-02-21 18:06:31
tags:
- LIFE ライフスタイル
description: ''
categories:
- ''
---


_Publié sur DopeKultur_  

![dope-trailer](https://i.ibb.co/9NkmTGK/dope-sundance.jpg)  

**Dope est l’une des sensations du  Sundance Dance 2015. Le film de Rick Famuyiwa a créé le buzz grâce à la  participation de A$AP Rocky. Le rappeur de Harlem y joue le rôle de Dom,  l’une des rencontres de Malcom, le protagoniste, de cette aventure.**  

L’histoire se déroule à Inglewood en Californie. Elle suit _Malcom_, interprété par **Shameik Moore**,  un lycéen, un peu geek sur les bords, qui rêve d’entrer à Harvard. Mais  les choses tournent mal, lors d’une soirée à LA où il se retrouve en  possession d’un sac rempli de drogue.  

Le film débute comme un teen movie  américain classique, avec une bande de ringards, qui se font malmener  par les brutes du lycée. Malcom et ses potes sont obsédés par les nineties,  surtout par le mouvement hip-hop de cette époque, dont ils reprennent  les codes vestimentaires, montre kitch, salopette en jeans, coupe de  cheveux à la **Will Smith dans Le prince de Bel-Air**. Mais très vite, l’ambiance change lorsqu’ils se retrouvent mêlés à une sordide affaire de stupéfiant.  

La guestlist ne se s’arrête pas à **A$AP Rocky**, on croise pas mal de têtes connues au court de se long métrage.  Parmi les plus connus le rappeur **Tyga** et **les membres d’Odd Future, Vince Staples et Casey Veggies**. De plus, nos trois héros forment un groupe de punk, dont les chansons sont réellement interprétées par **Pharell Williams** et ses amis de **N.E.R.D**.  

_Bonus trailer :_

<div align="center">
<iframe width="560" height="315" src="https://www.youtube.com/embed/3ViVPRWRRmk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
