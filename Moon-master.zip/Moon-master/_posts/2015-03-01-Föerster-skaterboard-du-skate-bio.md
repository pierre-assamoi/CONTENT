---
layout: post
title:  "Föerster Skaterboard, du skate bio"
image: ''
date:   2015-03-01 16:36:31
tags:
- LIFE ライフスタイル
description: ''
categories:
- ''
---

_Initialement publié sur DopeKultur_
![foersterskate]https://i.ibb.co/yVD83KC/foerster-skateboard-04.jpg

**Le skate est le sport de glisse  urbain par définition, à l’opposé du surf et du snowboard, qui se  veulent plus en contact avec notre belle planète bleue. Aujourd’hui, il  est possible de renouer le lien qui nous sépare de nos racines, grâce  ces planches 100% écologique, ou presque.**  

Deux frères berlinois, **Marco** et **[Sven Gabriel](https://svengabriel.com/149633/5290915/projects/foerster-skateboard-by-marco-sven)**, ont construit un _cruiser_ en bois, mais vraiment en bois, **en morceau d’arbre** pour être exact. La tranche est même encore recouverte d’écorce. Comme un pied de nez à l’industrialisation dégénérée de nos sociétés, le duo  allemand a conçu le **_Förster Skateboard_ (littéralement le Skateboard forestier)** avec leurs petites mimines, à l’ancienne.  À partir, d’une seule pièce de bois brute, taillée, poncée et percée, sur laquelle a été fixée une paire de trucks équipés de larges roues en gomme.

## FRENCH NATURAL SKATEBOARD
![Natural-skateboard](https://i.ibb.co/vXFk50H/natural-skateboarding.jpg)  

Un autre garçon a réalisé une planche  tout aussi singulière. Cette fois, il s’agit d’un artiste français,  connu sous le pseudonyme de **[Mr PLANT](http://monsieurplant.com/)**. L’ensemble de ses travaux est empreint d’un esprit écologique prononcé. Dans son porte-folio, on retrouve des reliques de la _street culture_ revisitée à sa manière, comme cette impressionnante paire de _sneakers_.  

![Nike-bio](https://i.ibb.co/nnhFQ9k/nike-bio-mr-plant.jpg)  

Le travail de **Christophe Guinet**, de son vrai nom, laisse sans voix. C’est un peu comme si la nature elle-même s’était chargée de reprendre ses droits dans un territoire où  elle n’a plus sa place depuis des années.  On ressent une sensation  similaire devant la planche du français. Plus rustre, que le Förster Skateboard, elle donne l’impression d’avoir été fabriquée à la va-vite  par un énorme bucheron. L’écorce recouvre toute la superficie du  plateau, sauf la partie réservée au grip, qui semble d’ailleurs avoir été découpé avec des ciseaux à bout rond Zouzou le hibou. L’ensemble est hirsute, massif et robuste.