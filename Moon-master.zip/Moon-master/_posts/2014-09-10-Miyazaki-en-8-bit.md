---
layout: post
title:  "Miyazaki en 8-bit"
image: 'https://i.ibb.co/zJSDpXR/capture-d-ecc81cran-2014-09-10-acc80-18-42-45.png'
date:   2014-09-10 16:41:31
tags:
- Pixel ピクセル (Pikuseru)
description: ''
categories:
- ''
---


_Initialement publié sur DopeKultur_  

![Miyazaki pixelart](https://i.ibb.co/zJSDpXR/capture-d-ecc81cran-2014-09-10-acc80-18-42-45.png) 

**Hayamo Miyazaki** part bientôt à la retraite, pour rendre hommage à son immense carrière, un fan réalise une vidéo en 8-bit qui retrace l’œuvre du réalisateur.

Le résultat est magnifique et surtout très fidèle, on y retrouve l’atmosphère douce, presque féerique des productions du studio Ghibli.

## Une vidéo de Whoispablo, disponible sur Vimeo :

<div align="center">
<iframe title="vimeo-player" src="https://player.vimeo.com/video/104063954" width="640" height="360" frameborder="0" allowfullscreen></iframe>
</div>
