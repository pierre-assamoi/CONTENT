---
layout: post
title:  "Aminé ambience la rentré!"
image: ''
date:   2015-10-09 00:06:31
tags:
- MUSIC 音楽
description: ''
categories:
- ''
---


_Publié sur DopeKultur_
![alt text](https://dopekultur.files.wordpress.com/2015/10/aminecc81-kaytranada-la-danse.jpg)

**La semaine dernière, j’ai découvert « La Danse » , un morceau  de Kaytranada avec Aminé, un chanteur que j’apprends encore à  connaître.**
Il faut absolument que je vous parle d’Aminé. C’est un rappeur, que  je viens de découvrir par hasard en me promenant sur _SoundClound_.  Originaire de Portland, le jeune MC chante sa ville comme personne ne  l’a fait avant lui. En fidèle ambassadeur, il n’en oublie aucun aspect.  On remue les bras frénétiquement quand il kick façon trap, on tremble  lorsque les percussions africaines retentissent et on fini fasciné par  les mystérieuses vibrations caribéennes.

<div align="center">
<iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/221299353&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
</div>
##La recette Aminé


Décomposons un peu cette savoureuse tambouille auditive. On y trouve  des sonorités aux origines diverses, mais pas que. Le MC alterne entre  des prod’ oldschool, à base de kick808 et des intrus plus modernes. La  tape est également parsemée de références au Hip-Hop des années 90 (l’an  – 25 avant l’arrivée de la trap, comme le disent les historiens).  
C’est le seulement le second projet d’Aminé et on a du mal à le  croire. Le disque dégage une telle harmonie, alors qu’il est composé de  morceaux tous plus différents les uns que les autres.  
Bien entendu, le garçon a été aidé et pas par n’importe qui. Le  talentueux Kaytranada a filé un coup de patte au MC de Portland. Il a  notamment réalisé toute l’instrumental du single de l’album « La  danse ». On retrouve le beat maker canadien sur deux autres excellents  sons ; YeYe et Buckwild. Je suis un immense fan de Kaytranada, pourtant  mon morceau préféré est produit par Tek.Lun. Perso, je ne le connaissais  pas avant, quelle surprise ! « Rage / Peace » fout une sacrée claque et  je m’en remets à peine.
Calling Brio est disponible gratuitement sur SoundCloud, jetez-y un  coup d’oeil. Au moins sur « La danse », qui vaut vraiment le détour,  même si le rap n’est pas votre truc.  
<div align="center">
<iframe width="100%" height="450" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/140133147&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
</div>
