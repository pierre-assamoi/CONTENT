---
layout: post
title:  "Le skate en 5 minutes"
image: ''
date:   2015-02-22 00:06:31
tags:
- LIFE ライフスタイル
description: ''
categories:
- ''
---
**Depuis son origine durant les  années 50 à aujourd’hui. Le skateboard est passé par un bon nombre de  phases. Marginalisé, détesté, interdit et finalement célébré, le  skateboard a une histoire riche en rebondissements, cette vidéo s’applique à les retracer avec humour.**

**Antonio Vicentini** et **David Galasse** ont fouillé les archives de la discipline pour réaliser ce clip. Des premières planches bricolées par « _a bunch of californian surfeurs bored of shitty waves_ » (« _une bande de surfeurs dépités par les vagues de piètre qualité_ »).  En passant par l’invention de la roue (en **Polyuréthane**), par _Cadillacs Wheels_ dans les années 70. Aux premières compétitions de freestyle. À la révolution qu’a été le _Ollie_, inventé par **Allan Gelfand**. La sortie de la première vidéo de skate, produite par Bones, avec des petits gars qui deviendront des légendes, **Steve Cabaliero, Rodney Mullen ou Tony Hawks**. Le déroulement des premiers X-Games en 1995. La légitimation de la discipline auprès du grand public.  
Le skateboard n’a pas cessé de grossir par la suite, jusqu’à devenir  le phénomène culturel que nous connaissons aujourd’hui. Dans la rue, à  la télévision, au cinéma, dans les jeux vidéos, la planche à roulettes fait désormais partit intégrante de notre paysage urbain.